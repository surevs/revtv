# -*- coding: utf-8 -*-
"""Placeholder modules - Coming Soon"""

def show_menu(handle, get_url):
    import xbmcgui
    xbmcgui.Dialog().notification('RevTV', 'This service is coming soon!')
